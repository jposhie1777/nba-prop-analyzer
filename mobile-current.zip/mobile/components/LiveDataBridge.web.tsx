// components/LiveDataBridge.web.tsx
export function LiveDataBridge() {
  return null;
}