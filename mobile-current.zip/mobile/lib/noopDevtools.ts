// lib/noopDevtools.ts
export const devtools = <T>(config: T): T => config;
export default devtools;