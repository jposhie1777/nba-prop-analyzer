import baseColors from "./color";

export type ThemeColors = typeof baseColors;