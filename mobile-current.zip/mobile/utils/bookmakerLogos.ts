// utils/bookmakerLogos.ts
export const BOOKMAKER_LOGOS: Record<string, any> = {
  draftkings: require("../assets/bookmakers/draftkings.png"),
  fanduel: require("../assets/bookmakers/fanduel.png"),
};
