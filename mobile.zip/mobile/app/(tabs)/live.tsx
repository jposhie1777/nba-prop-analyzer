import LiveGamesScreen from "../../screens/LiveGameScreen";

export default function LiveTab() {
  return <LiveGamesScreen />;
}
