import { View, Text } from "react-native";

export default function DevScreen() {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>Dev Tools</Text>
    </View>
  );
}