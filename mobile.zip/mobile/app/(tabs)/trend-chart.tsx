// app/(tabs)/more/trend-chart.tsx
import { View, Text } from "react-native";

export default function TrendChart() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Trend Chart OK</Text>
    </View>
  );
}