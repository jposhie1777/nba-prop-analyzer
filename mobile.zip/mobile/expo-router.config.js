// expo-router.config.js
module.exports = {
  unstable_static: false,
};