import 'react-native-reanimated';
import { registerRootComponent } from 'expo';

import App from './app';

registerRootComponent(App);