export const devtools = (fn: any) => fn;
