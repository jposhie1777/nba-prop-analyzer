// metro.config.js
const { getDefaultConfig } = require("expo/metro-config");
const path = require("path");

const config = getDefaultConfig(__dirname);

config.resolver.extraNodeModules = {
  ...(config.resolver.extraNodeModules || {}),
  "zustand/middleware/devtools": path.resolve(
    __dirname,
    "lib/noopDevtools.ts"
  ),
};

module.exports = config;
