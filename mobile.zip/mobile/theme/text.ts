const text = {
  title: 18,
  subtitle: 14,
  stat: 16,
  label: 12,
};

export default text;

